-- 9.	Get the count of policy claims categorised by sex. (Based on member_id).
select 
member_ID,
sex,
count(claim_ref)
from policy_details
inner join insurance_detail
on policy_details.policy_ID = insurance_detail.policy_ID
group by sex
order by member_ID ;