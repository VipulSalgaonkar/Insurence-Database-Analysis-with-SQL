-- 1.	Find out which policy type is considered most for each product code.
select prod_code, max(policy_type) ,count(policy_type) as count from policy_details
group by prod_code
order by count(policy_type) desc;