-- 3.	Find the statistics of maximum, minimum and average time gap (in days) between the claim dates and admit date.

select 
max(datediff(claim_dt,admit_dt)) as Maximum_Time_gap,
min(datediff(claim_dt,admit_dt)) as Minimum_Time_gap,
avg(datediff(claim_dt,admit_dt)) as average_Time_gap
from hospital_details
  inner join insurance_detail
	on hospital_details.hosp_ID = insurance_detail.hosp_ID;