-- 2.	Get the total insured sum categorised by TPA

select 
TPA,
sum(sum_insured) 
from insurance_detail
inner join policy_details
on insurance_detail.policy_ID = policy_details.policy_ID
group by TPA
order by sum(sum_insured);