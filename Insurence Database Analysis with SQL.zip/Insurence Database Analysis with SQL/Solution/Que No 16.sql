-- 16.	Get all the details of claims for the highest sum insured tpa classified as fraud.
select
claim_ref,
TPA,
count(sum_insured),
fraud
from insurance_detail
inner join policy_details
on insurance_detail.policy_ID = policy_details.policy_ID
group by TPA
order by count(sum_insured) desc;