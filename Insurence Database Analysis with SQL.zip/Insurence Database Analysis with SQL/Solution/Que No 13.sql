-- 13.	Find if there are any co-payments made.
select * from insurance_detail
where copayment != 0;