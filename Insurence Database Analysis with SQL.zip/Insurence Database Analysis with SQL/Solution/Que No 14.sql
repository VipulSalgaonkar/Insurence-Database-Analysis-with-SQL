-- 14.	Which is the most commonly used payment type for the policy claims.
select
payment_type,
count(payment_type) as Payment_type
from payment_details
group by payment_type
order by count(payment_type) desc;