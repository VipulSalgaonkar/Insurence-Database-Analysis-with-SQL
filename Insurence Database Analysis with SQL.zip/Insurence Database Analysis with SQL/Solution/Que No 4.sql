-- 4.	Find the relation between the claim amount and the treatment time (difference of admit date and discharge date).
select 
	claim_amt,
	datediff(discharge_dt,admit_dt) as treatment_time_Days
    from hospital_details;