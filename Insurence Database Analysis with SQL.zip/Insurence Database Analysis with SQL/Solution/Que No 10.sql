-- 10.	Get the count of members for each distinct policy reference value.
select
distinct(policy_ref),
count(member_ID)
from policy_details
group by policy_ref
order by count(member_ID) desc;