-- 15.	What is the average age of the members claiming for the insurance considering all the claim records.
select
avg(member_age) as Average
from insurance_detail
inner join policy_details 
on insurance_detail.policy_ID = policy_details.policy_ID;