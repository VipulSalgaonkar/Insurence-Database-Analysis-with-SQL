-- 5.	Get the sum of difference between claim amount and settlement amount categorised by payment type.#it Take time

SELECT 
	payment_type,
    (SUM(settle_amt)) - (SUM(claim_amt)) as difference
FROM 
    payment_details
full join hospital_details
group by payment_type
order by (SUM(settle_amt)) - (SUM(claim_amt));