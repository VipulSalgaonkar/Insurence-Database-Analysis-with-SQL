-- 1.	Find out which policy type is considered most for each product code.
select prod_code, max(policy_type) ,count(policy_type) as count from policy_details
group by prod_code
order by count(policy_type) desc;

-- 2.	Get the total insured sum categorised by TPA

select 
TPA,
sum(sum_insured) 
from insurance_detail
inner join policy_details
on insurance_detail.policy_ID = policy_details.policy_ID
group by TPA
order by sum(sum_insured);

-- 3.	Find the statistics of maximum, minimum and average time gap (in days) between the claim dates and admit date.

select 
max(datediff(claim_dt,admit_dt)) as Maximum_Time_gap,
min(datediff(claim_dt,admit_dt)) as Minimum_Time_gap,
avg(datediff(claim_dt,admit_dt)) as average_Time_gap
from hospital_details
  inner join insurance_detail
	on hospital_details.hosp_ID = insurance_detail.hosp_ID;

    
-- 4.	Find the relation between the claim amount and the treatment time (difference of admit date and discharge date).
select 
	claim_amt,
	datediff(discharge_dt,admit_dt) as treatment_time_Days
    from hospital_details;
    
-- 5.	Get the sum of difference between claim amount and settlement amount categorised by payment type.#it Take time

SELECT 
	payment_type,
    (SUM(settle_amt)) - (SUM(claim_amt)) as difference
FROM 
    payment_details
full join hospital_details
group by payment_type
order by (SUM(settle_amt)) - (SUM(claim_amt));


-- 6.	Find the statistics of maximum, minimum and average time gap (in days) between the discharge date and payment date categorised by payment type.
-- 
select 
payment_type,
max(datediff(discharge_dt,payment_dt)) as Maximum_Time_gap,
min(datediff(discharge_dt,payment_dt)) as Minimum_Time_gap,
avg(datediff(discharge_dt,payment_dt)) as average_Time_gap
from payment_details
  full join hospital_details
-- on hospital_details.hosp_ID = insurance_detail.hosp_ID
group by payment_type;
-- by max(datediff(discharge_dt,payment_dt)),min(datediff(discharge_dt,payment_dt)),avg(datediff(discharge_dt,payment_dt));


-- 7.	What is the average tenure for a policy taken categorised by the product code. (Difference between policy start and end date)

select
prod_code,
datediff(policy_start_date,policy_end_date) as policy_difference
from policy_details;


-- 8.	Find out which hospital type has claims classified as fraud more either networked or non-networked hospitals.
select
hosp_type,
count(fraud = 1)
from hospital_details
inner join insurance_detail
on hospital_details.hosp_ID = insurance_detail.hosp_ID
group by hosp_type
order by count(fraud);

-- 9.	Get the count of policy claims categorised by sex. (Based on member_id).
select 
member_ID,
sex,
count(claim_ref)
from policy_details
inner join insurance_detail
on policy_details.policy_ID = insurance_detail.policy_ID
group by sex
order by count(claim_ref);


-- 10.	Get the count of members for each distinct policy reference value.
select
distinct(policy_ref),
count(member_ID)
from policy_details
group by policy_ref
order by count(member_ID) desc;

-- 11.	For claims classified as fraud, get the details of claims recommended to be genuine
select
policy_ID,
claim_ref,
recommendation,
fraud
from insurance_detail
where fraud = '1' and recommendation = 'Genuine';

-- 12.	Validate whether the sum of all the charges matches to the claim amount.
SELECT hosp_ID,claim_amt,
(round(nursing_charge + surgery_charge + cons_fee+test_charge+pharmacy_cost+other_charge+pre_hosp_charge+post_hosp_charge+other_charge_non_hosp,2)) AS all_charges
FROM hospital_details;

-- 13.	Find if there are any co-payments made.
select * from insurance_detail
where copayment != 0;


-- 14.	Which is the most commonly used payment type for the policy claims.
select
payment_type,
count(payment_type) as Payment_type
from payment_details
group by payment_type
order by count(payment_type) desc;

-- 15.	What is the average age of the members claiming for the insurance considering all the claim records.
select
avg(member_age) as Average
from insurance_detail
inner join policy_details 
on insurance_detail.policy_ID = policy_details.policy_ID;

-- 16.	Get all the details of claims for the highest sum insured tpa classified as fraud.
select
TPA,
count(policy_ID),
fraud
from insurance_detail
where fraud = 1
group by TPA
order by count(policy_ID) desc;

-- 17.	Add a new column to insurance detail table named as profit which the difference between claim amount and settlement amount.

SELECT 
	payment_type,
    (SUM(settle_amt)) - (SUM(claim_amt)) as difference
FROM 
    payment_details
full join hospital_details
INSERT INTO insurance_detail(profit) VALUES (SUM(settle_amt)) - (SUM(claim_amt)));


alter table insurance_detail
add Profit int;
select * from insurance_detail;

select
profit,
round(claim_amt -settle_amt) as Profit
from insurance_detail,payment_details
full join hospital_details;

-- full join hospital_details;


update insurance_details 
set Profit = insurance_details.Profit



-- 18.	Find out which tpa made highest profit.
select
TPA,
count(policy_ID) as Policies
from insurance_detail
group by TPA
order by count(policy_ID) desc;


-- 19.	Find the relationship between sum insured and the policy tenure.
select
sum_insured,
datediff(policy_end_date,policy_start_date)
from policy_details;

-- 20.	For a new policy insurance which tpa, product code and policy type is recommended according to your observation of analysis.
-- product_code will be w
-- policy_type will be L
-- TPA will be X
