-- 8.	Find out which hospital type has claims classified as fraud more either networked or non-networked hospitals.
select
hosp_type,
count(fraud = 1)
from hospital_details
inner join insurance_detail
on hospital_details.hosp_ID = insurance_detail.hosp_ID
group by hosp_type
order by count(fraud);
