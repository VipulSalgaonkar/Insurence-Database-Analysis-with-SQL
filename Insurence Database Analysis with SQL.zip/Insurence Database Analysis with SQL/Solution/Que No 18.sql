-- 18.	Find out which tpa made highest profit.
select
TPA,
count(policy_ID) as Policies
from insurance_detail
group by TPA
order by count(policy_ID) desc;