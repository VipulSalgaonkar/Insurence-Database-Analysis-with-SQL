-- 11.	For claims classified as fraud, get the details of claims recommended to be genuine
select
policy_ID,
claim_ref,
recommendation,
fraud
from insurance_detail
where fraud = '1' and recommendation = 'Genuine';