-- 19.	Find the relationship between sum insured and the policy tenure.
select
sum_insured,
datediff(policy_end_date,policy_start_date) as Policy_tenure
from policy_details;