-- 7.	What is the average tenure for a policy taken categorised by the product code. (Difference between policy start and end date)

select
prod_code,
datediff(policy_start_date,policy_end_date) as policy_difference
from policy_details;