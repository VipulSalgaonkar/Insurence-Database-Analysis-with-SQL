select id.TPA,id.claim_ref,id.claim_dt,pd.policy_ref,pd.member_ID,pd.sex,pd.dob,pd.member_age,pd.policy_start_date,pd.policy_end_date,
pd.prod_code,p.product_type,pd.policy_type,pt.typedetails,
hd.hospital_code,hd.hosp_zipcode,hd.hosp_type,hd.admit_dt,hd.discharge_dt,hd.claim_amt,hd.nursing_charge,
hd.surgery_charge,hd.cons_fee,hd.test_charge,hd.pharmacy_cost,hd.other_charge,hd.pre_hosp_charge,hd.post_hosp_charge,hd.other_charge_non_hosp,
pay.settle_amt,pay.settle_amt,pay.payment_type,pay.payment_desc,pay.payment_dt,
id.copayment,id.recommendation,id,fraud from insurance_detail id
join policy_details pd on id.policy_ID=pd.policy_ID
join product p on p.prod_code=pd.prod_code
join policytype pt on pt.policy_type=pd.policy_type
join hospital_details hd on hd.hosp_ID=id.hosp_ID
join payment_details pay on pay.payment_ID=id.payment_ID;