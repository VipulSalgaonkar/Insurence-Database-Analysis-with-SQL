



create table insurance_detail(
ID int,
TPA char,
policy_ID int,
claim_ref varchar(50),
claim_dt date,
hosp_ID int,
copayment int,
payment_ID int,
recommendation varchar(20),
fraud int);

create table policy_details(
policy_ID int,
policy_ref varchar(50),
member_ID varchar(30),
sex char,
dob date,
member_age int,
policy_start_date date,
policy_end_date date,
prod_code char,
policy_type char,
sum_insured int);

create table product(
prod_code char,
product_type varchar(100));

create table policytype(
policy_type char,
typedetails varchar(100));

create table hospital_details(
hosp_ID int,
hospital_code varchar(50),
hosp_zipcode varchar(50),
hosp_type char,
admit_dt date,
discharge_dt date,
claim_amt float,
nursing_charge float,
surgery_charge float,
cons_fee float,
test_charge float,
pharmacy_cost float,
other_charge float,
pre_hosp_charge float,
post_hosp_charge float,
other_charge_non_hosp float);

create table payment_details(
payment_ID int,
settle_amt float,
payment_dt date,
payment_type char,
payment_desc varchar(100));



